<template>
  <!--  <h1>酒店</h1>-->
  <!-- <DefaultHeader/> -->
  <div class="container_h">
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
      <el-breadcrumb-item><a>{{ title }}</a> </el-breadcrumb-item>
      <el-breadcrumb-item>正文</el-breadcrumb-item>
    </el-breadcrumb>
    <br>
  </div>
  <h1>海南历史文化</h1><br>
  <div class="container">
    <div class="con">
      <p style="text-align: justify;">
        在华夏大地的南端，有一座美丽的海岛 —— 海南。它宛如一颗璀璨的明珠，镶嵌在广袤的南海之上。海南不仅拥有迷人的自然风光，更有着源远流长、丰富多彩的历史文化，这些文化瑰宝如同点点繁星，照亮了海南发展的漫漫长路。
      </p>
      <p style="text-align: justify;">
        追溯海南的历史，早在远古时期，这里便有人类活动的踪迹。先秦时期，海南属百越之地，那时的先民们在这片土地上辛勤劳作，开启了海南文明的先河。到了秦汉时期，中央政权开始对海南进行管辖，汉武帝元封元年，在海南设置珠崖、儋耳两郡，从此海南正式纳入中国版图。此后，历经唐宋元明清各朝，海南的行政建制不断发展演变，与中原地区的联系也日益紧密。
      </p>
      <p style="text-align: justify;">
        以下是按时间节点梳理的海南历史文化发展：
      </p>
      <p style="text-align: justify;"><strong>远古至先秦时期</strong></p>
      <p style="text-align: justify;">
        海南岛上就有人类活动踪迹，先秦时属百越之地，先民在此劳作，开启海南文明先河.
      </p>
      <p style="text-align: justify;"><strong>秦汉时期</strong></p>
      <p style="text-align: justify;">
        公元前110年，汉武帝平定南越，在海南设珠崖、儋耳二郡，海南正式归入中原王朝版图。汉元帝时曾弃置珠崖，至隋朝在冼夫人作用下再入中原王朝版图，当时增设临振郡.
      </p>
      <p style="text-align: justify;"><strong>唐朝时期 </strong></p>
      <p style="text-align: justify;">
        海南岛上三郡变为三州，即崖州、儋州、振州，唐朝未在海南设羁縻州，而是直接派官吏统率，设州县管辖，并设崖州都督府、琼州都督府等。 鉴真第五次东渡日本时到过振州、崖州等地，传播文化知识.
      </p>
      <p style="text-align: justify;"><strong>宋朝时期 </strong></p>
      <p style="text-align: justify;">
        公元972年，崖州被撤销并入琼州，振州改名为崖州，形成“琼州”“崖州”南北呼应格局。北宋熙宁年间，崖州、儋州和万安州由州改为军，南宋时又全部改为县。苏轼谪居儋州三载，促进了当地文化发展
      </p>
      <p style="text-align: justify;"><strong>元朝时期 </strong></p>
      <p style="text-align: justify;">
        三亚地区为吉阳军所辖，元元统元年，判官李泌创建谯楼。黄道婆流落至崖州，学习纺织技能后返回故乡促进了当地纺织业发展.
      </p>
      <p style="text-align: justify;"><strong>明清时期 </strong></p>
      <p style="text-align: justify;">
        明初，朝廷将琼州升级为琼州府，领崖州、儋州、万州，清承明制，行政区划变化不大。明清时期，海南经济社会发展迅速，府城形成古城格局，崖州、儋州的镇墟集市、海运和渔业等都有所发展，还涌现出了海瑞、丘濬等名臣先贤.
      </p>
      <p style="text-align: justify;"><strong>近现代时期 </strong></p>
      <p style="text-align: justify;">
        海南历史文化在传承中不断发展，20世纪50年代的农垦文化，为海南的经济建设和社会发展做出了重要贡献 。如今，海南正加快建设自由贸易港，在传承和弘扬历史文化的同时，吸收融合新的文化元素，努力打造具有国际影响力的文化旅游胜地.
      </p>
      <p style="text-align: justify;">
        在海南的历史进程中，贬官文化留下了浓墨重彩的一笔。自唐朝以来，许多文人政客因政治原因被贬谪到海南。如唐代的李德裕，宋代的苏轼、李纲等。他们虽身处逆境，但却将中原地区先进的文化、思想和技术带到了海南。苏轼在儋州期间，办学堂、兴教化，培养出了海南历史上第一位举人姜唐佐。他的诗词文章也在海南广泛传播，对海南的文化发展产生了深远的影响。这些贬官们在海南留下的足迹和故事，成为了海南历史文化中独特的一部分，激励着后人不断奋进。
      </p>
      <p style="text-align: justify;">
        海南的海洋文化同样独具魅力。作为一个四面环海的岛屿，海洋赋予了海南人勇敢、坚韧的性格。自古以来，海南的渔民们就以海为生，他们驾驶着渔船，在波涛汹涌的大海上穿梭，积累了丰富的航海经验。《更路簿》就是他们智慧的结晶，这本记录着南海海域航线和岛礁信息的航海手册，见证了海南渔民对南海的开发和探索，也体现了他们与海洋之间深厚的情感纽带。此外，海南的海上贸易历史悠久，早在唐宋时期，海南就已经成为海上丝绸之路的重要中转站。来自不同国家和地区的商船在这里汇聚，带来了多元的文化和商品，促进了海南与世界的交流与融合。
      </p>
      <p style="text-align: justify;">
        海南还是一个多民族聚居的地方，黎族、苗族等少数民族在这里繁衍生息，他们创造了丰富多彩的民族文化。黎族的织锦技艺闻名遐迩，那精美的图案、绚丽的色彩，无不展现出黎族人民的智慧和创造力。黎族的传统节日
        “三月三”，更是充满了浓郁的民族风情。在这一天，黎族同胞们身着盛装，载歌载舞，举行盛大的庆祝活动，表达对生活的热爱和对美好未来的向往。苗族的服饰、歌舞等文化元素也独具特色，为海南的文化宝库增添了别样的光彩。
      </p>
    </div>

    <div class="imgList">
      <img src="@/assets/历史文化用图1.jpg" alt="" class="img1">
      <img src="@/assets/历史文化用图2.jpg" alt="" class="img1">
      <img src="@/assets/历史文化用图3.jpg" alt="" class="img1">
      <img src="@/assets/历史文化用图4.jpg" alt="" class="img1">
      <img src="@/assets/历史文化用图5.jpg" alt="" class="img1">
    </div>
  </div>
  <!-- <HomeFooter /> -->
</template>

<script>
import DefaultHeader from "@/components/DefaultHeader.vue";
import HomeFooter from "@/components/HomeFooter.vue";
import SelfTemplate2 from "@/components/SelfTemplate2.vue";

export default {
  name: "House",
  data() {
    return {
      title: '历史文化',
      content: [],
      //
    }
  },
  components: { DefaultHeader, HomeFooter, SelfTemplate2 }
}
</script>

<style scoped>
.container {
  width: 60%;
  /*background-color: aqua;*/
  margin-left: 20%;
  margin-bottom: 50px;
}

.container_h {
  width: 60%;
  /*background-color: aqua;*/
  margin-left: 20%;
}

.el-breadcrumb {
  padding: 15px 0;
  /*background-color: white;*/
  border-bottom: 1px solid rgb(153, 153, 153);
}

h1 {
  text-align: center;
}

p {
  font-size: medium;
  text-indent: 2em;
  line-height: 1.6;
}

.imgList {
  display: flex;
}

.img1 {
  width: 19%;
  margin-right: 1%;
}
</style>