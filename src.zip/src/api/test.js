import { get } from "../util/request";

// test
export const testService = () => get('/test')